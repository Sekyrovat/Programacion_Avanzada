/* Figura 10.2: fig10_02.c
   Uso de los operadores de estructura
   miembro y de apuntador a estructura */
#include <stdio.h>
#include <string.h>

/* definici�n de la estructura carta */         
struct carta {                           
   char *cara; /* define el apuntador cara */
   char *palo; /* define el apuntador palo */
   char ID[11];
}; /* fin de la estructura carta */             

int main()
{ 
   struct carta unaCarta;    /* define una estructura variable carta */   
   struct carta *ptrCarta; /* define un apuntador a una estructura carta */

   /* coloca cadenas dentro de unaCarta */
   unaCarta.cara = "As";   
   unaCarta.palo = "Espadas";
   strcpy(unaCarta.ID, "A00816446");

   ptrCarta = &unaCarta; /* asigna la direcci�n de unaCarta a ptrCarta */

   printf( "%s%s%s\n%s%s%s\n%s%s%s\n", unaCarta.cara, " de ", unaCarta.palo,
      ptrCarta->cara, " de ", ptrCarta->palo,                           
      ( *ptrCarta ).cara, " de ", ( *ptrCarta ).palo );                 
   printf("%s\n",ptrCarta->ID);
   return 0; /* indica terminaci�n exitosa */
 
} /* fin de main */




/**************************************************************************
 * (C) Copyright 1992-2004 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/
