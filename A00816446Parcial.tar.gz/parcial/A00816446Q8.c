#include <stdio.h>


//A00816446

int main(void)
{
	int my_array[] ={1,23,17,4,-5,100};
	int i;

	

    printf("\n\n");
    for (i = 0; i < 6; i++)
    {
//Imprimir como apuntador la lista
      printf("my_array[%d] = %d \n",i,*(my_array+i));   /*<-- A */
      
    }
    return 0;
}
